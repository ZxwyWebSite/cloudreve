import * as actions from "./action";
import * as reducers from "./reducer";

export default {
    actions,
    reducers,
};
